# README 配图练习

此项目用于练习，不是真实论文。编译器选择 XeLaTeX，主文件为 main.tex。

本地编译：xelatex main.tex → biber main → xelatex main.tex → xelatex main.tex。

正文位于 chap/，姓名和题目在 main.tex，虚构文献在 ref.bib。图表、公式与文献引用可对照 GitHub README 学习。

chap/chapter1.tex 中的 clearpage 只用于把各项练习分页截图，普通正文不必每节分页。

本项目保留原始 xitthesis.cls 和 logo.png，不包含微软字体。所有占位内容均不可直接作为正式论文提交。
