# 从当前 Windows 系统字体目录复制论文所需字体到项目 fonts/。
# 仅用于你自己有权使用的本机字体与私有论文项目；请勿公开再分发字体文件。
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $ProjectRoot "fonts"
$Source = Join-Path $env:WINDIR "Fonts"

New-Item -ItemType Directory -Force -Path $Dest | Out-Null

$FontFiles = @(
    "simsun.ttc",
    "simhei.ttf",
    "times.ttf",
    "timesbd.ttf",
    "timesi.ttf",
    "timesbi.ttf",
    "simfang.ttf",
    "simkai.ttf"
)

Write-Host "Windows font source: $Source"
Write-Host "Project font target: $Dest"
Write-Host ""

foreach ($Name in $FontFiles) {
    $Src = Join-Path $Source $Name
    $Dst = Join-Path $Dest $Name
    if (Test-Path $Src) {
        Copy-Item -Force $Src $Dst
        Write-Host "[OK] $Name"
    } else {
        Write-Host "[Missing] $Name"
    }
}

Write-Host ""
Write-Host "Done. Required for exact reference typography: simsun.ttc, simhei.ttf, times.ttf, timesbd.ttf, timesi.ttf, timesbi.ttf"
Write-Host "Optional: simfang.ttf, simkai.ttf"
Write-Host "Now upload the whole project to Overleaf and select XeLaTeX."
