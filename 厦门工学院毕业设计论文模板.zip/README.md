# 厦门工学院本科毕业论文（设计）LaTeX 纯模板版 - 新手批注版

> **Overleaf 文件树乱码说明（v1.9）：**旧 ZIP 内少数中文文件名没有正确的 UTF-8 ZIP 标记，Overleaf 会显示成乱码。v1.9 已把所有辅助文件名改成 ASCII；论文正文仍保持 UTF-8 中文，不受影响。声明页的“独创性声明”和“关于论文使用授权的说明”也已加粗。


本版本在模板关键代码位置加入了较详细的中文批注，便于第一次使用 LaTeX 的同学快速修改。批注主要位于：

- `main.tex`：论文信息填写、编译顺序、摘要/正文/参考文献/附录入口。
- `xitthesis.cls`：页边距、字体、页眉页脚、封面、目录、摘要、参考文献、附录等模板格式说明。
- `chap/*.tex`：章节写法、图片、表格、公式、代码块、引用文献、交叉引用示例。
- `ref.bib`：参考文献数据库写法说明。
- `Makefile`：命令行一键编译说明。

> **详细教学：**项目根目录新增 `LATEX_OVERLEAF_GUIDE.md`，包含 Overleaf、封面信息、章节、图片、三线表、公式、引用、Biber、代码块、附录、字体与常见报错的完整新手教程。

## 1. 最快使用步骤

1. 打开 `main.tex`，填写论文题目、姓名、学号、专业、年级、指导教师、日期、关键词。
2. 打开 `chap/abstract.tex`，填写中文摘要和英文摘要。
3. 打开 `chap/chapter1.tex` 至 `chap/chapter5.tex`，替换章节标题和正文内容。
4. 打开 `chap/conclusion.tex`，填写总结。
5. 打开 `ref.bib`，录入参考文献；正文中使用 `\cite{文献键}` 引用。
6. 编译生成 PDF。

## 2. 编译方式

推荐使用 XeLaTeX + Biber：

```bash
xelatex main.tex
biber main
xelatex main.tex
xelatex main.tex
```

Overleaf 中：

- `Menu -> Compiler` 选择 `XeLaTeX`。
- 上传整个模板文件夹，不要只上传 `main.tex`。
- 如果目录、页码、参考文献没有刷新，连续重新编译两三次。

## 3. 文件结构

```text
main.tex                         主文件；填写论文基本信息，控制全文结构
xitthesis.cls                    模板样式文件；控制封面、字体、页边距、页眉、目录等
ref.bib                          参考文献数据库
Makefile                         命令行编译辅助文件
chap/abstract.tex                中英文摘要
chap/chapter1.tex                第 1 章
chap/chapter2.tex                第 2 章，含图片/表格/公式注释示例
chap/chapter3.tex                第 3 章，含列表示例
chap/chapter4.tex                第 4 章，含单位写法示例
chap/chapter5.tex                第 5 章，含代码块示例
chap/conclusion.tex              总结
chap/acknowledgements.tex        谢辞
chap/appendixA.tex               附录一
chap/appendixB.tex               附录二
figures/logo.png                 封面 logo
preview.pdf                      模板预览 PDF
```

## 4. LOGO 使用

封面已按参考图二改为“学校完整 Logo 图形标识 + 本科毕业论文（设计） + 信息栏”的格式，不再单独另打大号“厦门工学院”文字。模板包已内置 `figures/logo.png`。

如需替换为学校最新标识：

1. 将新 logo 文件放入 `figures/` 文件夹。
2. 在 `main.tex` 中修改：

```tex
\XITLogo{figures/logo.png}
```

支持 `png`、`jpg`、`pdf` 等 XeLaTeX 可读取的图片格式。

## 5. 如何插入图片

把图片放入 `figures/` 文件夹，然后在正文中写：

```tex
\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.75\textwidth]{figures/example.png}
  \caption{图片标题}
  \label{fig:example}
\end{figure}
```

正文引用：

```tex
如图~\ref{fig:example} 所示。
```

## 6. 如何插入表格

```tex
\begin{table}[htbp]
  \centering
  \caption{表格标题}
  \label{tab:example}
  \begin{tabular}{ccc}
    \toprule
    指标 & 数值 & 说明 \\
    \midrule
    A & 1.00 & 示例 \\
    B & 2.00 & 示例 \\
    \bottomrule
  \end{tabular}
\end{table}
```

正文引用：

```tex
见表~\ref{tab:example}。
```

## 7. 如何写参考文献

在 `ref.bib` 中添加文献条目：

```bibtex
@article{zhang2026example,
  author  = {张三 and 李四},
  title   = {论文题目},
  journal = {期刊名称},
  year    = {2026},
  volume  = {10},
  number  = {2},
  pages   = {1-10}
}
```

正文引用：

```tex
相关研究表明……\cite{zhang2026example}。
```

参考文献会自动出现在“总结”和“谢辞”之间，并自动加入目录。

## 8. 常见问题

### 目录页码不对

重新编译两到三次。LaTeX 需要多次编译才能刷新目录、交叉引用和页码。

### 参考文献不显示

检查三点：

1. `ref.bib` 中有文献条目。
2. 正文中使用了 `\cite{文献键}`。
3. 编译顺序包含 `biber main`。

如果只是想让预览版显示所有文献，可在 `main.tex` 中取消：

```tex
% \nocite{*}
```

改成：

```tex
\nocite{*}
```

### 中文乱码或字体报错

必须使用 XeLaTeX 编译，不要使用 pdfLaTeX。

### 不需要附录怎么办

在 `main.tex` 中注释掉附录入口：

```tex
% \include{chap/appendixA}
% \include{chap/appendixB}
```

## 9. 本版本修改说明

- 删除原示例论文中的全部具体题目、作者、学号、专业、指导教师和正文内容。
- 封面使用用户提供的厦门工学院 logo 图片，不再额外排印大号“厦门工学院”文字。
- 封面各信息项统一使用下划线字段。
- 前置部分页眉为“厦门工学院  毕业论文（设计）”，正文页眉显示论文题目，页眉下方带横线。
- 目录中固定保留“参考文献”，位置为“总结”和“谢辞”之间。
- 在必要代码位置加入中文批注，覆盖新手常见修改场景。


## 10. 对照往届论文的本次格式校正

- 目录不再把“摘要 / Abstract”列入目录，从“第 1 章”开始，与参考论文一致。
- 目录中的章标题、总结、参考文献、谢辞、附录条目改回宋体常规字重，不再整行呈现黑体效果。
- 章标题调整为小二号黑体；节标题与小节标题统一为小三号黑体；四级标题使用小四号宋体。
- 小节与四级标题增加逐级缩进，使正文层级关系更接近参考论文。
- 中英文摘要标题、摘要正文字号和关键词字号按参考论文重新分层；摘要正文采用五号字。
- 封面重新校准纵向节奏与字体：论文类型、信息栏、各字段行距和日期位置均以参考论文为基准；建议正式题目保持适中长度以维持单行封面效果。
- AI 示例版与新手批注版现在使用同一套核心版式规则，后续维护时更不容易出现两份模板风格漂移。

> **封面字段字重说明：** 模板只使用字体本身的常规字形（`\mdseries`），不会额外叠加 `\bfseries`。参考论文本身的论文题目使用黑体，所以题目会自然比姓名等宋体内容更醒目。
## 11. 2026-08-30 参考论文精细对齐说明


- 对参考 PDF 的嵌入字体重新核验后，精确模式锁定为 SimSun / SimHei / Times New Roman；Overleaf 项目内上传 `fonts/` 字体后自动启用。未上传时使用 FandolSong / FandolHei / Liberation Serif 回退。
- Windows 本地优先使用 SimSun / SimHei；中文正文中的英文和数字跟随宋体，标题中的数字/英文跟随黑体。
- 正文左右页边距约 22 mm，正文小四号，基线距离约 20 pt。
- 章标题 18 pt 黑体；节、小节 15 pt 黑体；四级标题 12 pt 宋体。
- 目录正文 12 pt 宋体常规字重；图表标题与表内文字约 10.5 pt。
- 图、表、公式编号改为 `2-1`、`3-1` 这类短横线形式。
- 独创性声明页标题、正文、行距和签名位置按参考 PDF 重新校准。
- 封面 Logo、纵向位置、下划线宽度、字段字号和日期位置按参考 PDF 重做。
- 封面下划线改为独立 0.48 pt 规则线，避免 `\underline` 因汉字/数字高度不同造成上下漂移。
- 前置部分左右边距按参考 PDF 调为约 25 mm / 20 mm，正文约 22 mm / 22 mm；页眉、页脚基线重新校准。
- 中文摘要正文固定约 24 pt 基线距；英文摘要正文固定约 20 pt 基线距，避免全局行距系数把英文摘要撑成两页。
- 移除 `titlesec` 对 `ctexset` 章节间距的覆盖，正文中的节/小节前后间距重新按参考 PDF 的典型页面校准。

Overleaf 服务器本身不预装微软 SimSun/SimHei；本模板已支持在私有项目的 `fonts/` 目录中加载你自行提供且有权使用的字体文件。没有原版字体时仍可用开源回退正常编译。 项目根目录的 `copy_windows_fonts.ps1` 可从你自己的 Windows 字体目录复制所需文件。

